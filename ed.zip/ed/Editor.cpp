#include "Editor.h"

void Editor::loop(){

    regex x(R"(\d)");
    regex plus(R"(+\d)");
    regex back(R"(-\d)");
    regex lastLine("$");
    regex a("a");
    regex i("i");
    regex c("c");
    regex d("d");
    regex src(R"(/\w+)");
    regex swithOldNew(R"(s/\w+/\w+/?)");
    regex j("j");
    regex w(R"(w/\w+)");
    regex Q("Q");

    while(true){
        string U_input;
        getline(cin,U_input);
    
        if(regex_match(U_input, x)){
          doc.goToLine(stoi(U_input));
        }
         else if(regex_match(U_input, plus)){
          doc.skeepLines(stoi(U_input));
        }
         else if(regex_match(U_input, back)){
          doc.goBackLines(stoi(U_input));
        }
         else if(regex_match(U_input, lastLine)){
          doc.goToLastLine();
        }
         else if(regex_match(U_input, a)){
            doc.addLinesAfter();
        }
         else if(regex_match(U_input, i)){
          doc.addLinesBefore();
        }
         else if(regex_match(U_input, c)){
             doc.changeLine();
        }
         else if(regex_match(U_input, d)){
             doc.deletLine();
        }
         else if(regex_match(U_input, src)){
             doc.serchString(U_input);
        }
        if(regex_match(U_input, swithOldNew)){
            string first=U_input.substr(2);
            int find1 =first.find("/");
            string one= first.substr(0,find1);
            int find2=first.rfind("/");
            string two;
            if(find2==find1) {
                two= first.substr(find1+1);
            }else{
                two= first.substr((find1+1),find2-find1-1);
            }
            doc.switchLines(one,two);
        }
        else if(regex_match(U_input, j)){
             doc.joinLines();
        }

         else if(regex_match(U_input,w)){
            doc.writeToFile(U_input);
        }

        else if(regex_match(U_input, Q)){
            doc.quit();
        }
    }
}